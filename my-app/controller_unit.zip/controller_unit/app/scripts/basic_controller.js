var myModule = angular.module('myModule', []);
	myModule.controller('MyCtrl', function() {
		this.location = "New Yorks";
		this.name = "smith Johnson";
		});